const $ = x => document.querySelector(x);
const burgerButton = $('.header-top-burger_menu');
const headerTopMenu = $('.header-top-menu');
const headerTopBurgerMenuTop = $('.header-top-burger_menu-top');
const headerTopBurgerMenuCenter = $('.header-top-burger_menu-center');
const headerTopBurgerMenuBottom = $('.header-top-burger_menu-bottom');

burgerButton.addEventListener('click', e => {
    headerTopMenu.classList.toggle('active_menu');
    headerTopBurgerMenuTop.classList.toggle('active_burger_top');
    headerTopBurgerMenuCenter.classList.toggle('active_burger_center');
    headerTopBurgerMenuBottom.classList.toggle('active_burger_bottom');
});