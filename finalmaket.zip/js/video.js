        // Получаем видео и элементы управления
        let videoFile = document.querySelector(".main-video_present-file");
        let videoBtn = document.querySelector(".main-video_present-control-btn");
        let svgPlay = document.querySelector(".main-video_present-control-btn-play");
        let svgPause = document.querySelector(".main-video_present-control-btn-pause");
        let timer = document.querySelector(".main-video_present-control-timer");

        // Устанавливаем уровень звука 1%
        videoFile.volume = 0.01;

        // Запускаем / останавливаем врспроизведение
        videoBtn.addEventListener('click', function() {
            if (videoFile.paused) {
                videoFile.play();

            } else {
                videoFile.pause();
            }
        }, false);

        // Сменяем иконку на время проигрывания файла
        videoFile.addEventListener('play', function() {
            svgPlay.style.cssText = "display: none;";
            svgPause.style.cssText = "display: block;";
        }, false);

        // Сменяем иконку на время паузы
        videoFile.addEventListener('pause', function() {
            svgPlay.style.cssText = "display: block;";
            svgPause.style.cssText = "display: none;";
        }, false);

        // Сброс счётчика времени при окончании восроизведения
        videoFile.addEventListener('ended', function() {
            videoFile.currentTime = 0;
        }, false);

        // Обновляем тайм-код на странице
        videoFile.addEventListener('timeupdate', function() {
            timer.innerHTML = secondsToTime(videoFile.currentTime);
        }, false);

        // Рассчет отображаемого времени
        function secondsToTime(time) {

            var h = Math.floor(time / (60 * 60)),
                dm = time % (60 * 60),
                m = Math.floor(dm / 60),
                ds = dm % 60,
                s = Math.ceil(ds);
            if (s === 60) {
                s = 0;
                m = m + 1;
            }
            if (s < 10) {
                s = '0' + s;
            }
            if (m === 60) {
                m = 0;
                h = h + 1;
            }
            if (m < 10) {
                m = '0' + m;
            }
            if (h === 0) {
                fulltime = m + ':' + s;
            } else {
                fulltime = h + ':' + m + ':' + s;
            }
            return fulltime;
        }